package tetris;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.awt.Color;
import java.awt.Point;

class TetrisTest {
    private GameController game;

    @BeforeEach
    void setUp() {
        game = new GameController();
    }

    @Test
    void testPuntuacionInicial() {
        assertEquals(0, game.currentScore(), "La puntuación inicial debe ser 0");
    }

    @Test
    void testMoverPieza() {
        Tetromino piezaInicial = game.getCurrentPiece();
        int xInicial = piezaInicial.getShape()[0].x;
        int yInicial = piezaInicial.getShape()[0].y;
        
        game.movePiece(1, 0); 
        assertEquals(xInicial + 1, piezaInicial.getShape()[0].x, "La pieza debe moverse a la derecha");
        assertEquals(yInicial, piezaInicial.getShape()[0].y, "La pieza no debe moverse en el eje Y");
    }

    @Test
    void testColocacionDePieza() {
        game.dropPiece();
        assertTrue(game.getBoard().isPiecePlaced(), "La pieza debe estar colocada en el tablero");
    }
    
    @Test
    void testLimpiezaDeLinea() {
        Board board = game.getBoard();
        
        for (int x = 0; x < 10; x++) {
            board.getGrid()[19][x] = Color.RED;
        }
        
        int lineasEliminadas = board.clearLines();
        assertEquals(1, lineasEliminadas, "Se debe eliminar una línea completa");
    }
}
