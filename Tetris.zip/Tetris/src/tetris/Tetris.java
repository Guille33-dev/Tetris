package tetris;

import java.io.File;

import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class Tetris {
	public static void main(String[] args) {
		GameController game = new GameController();
		System.out.println("Bienvenides a Tetris!");
		System.out.println("Puntuación inicial: " + game.currentScore());
		
		game.dropPiece();
		System.out.println("Puntuación: " + game.currentScore());
	}
}
